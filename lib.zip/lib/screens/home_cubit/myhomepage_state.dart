part of 'myhomepage_cubit.dart';

@immutable
abstract class MyhomepageState {}

class MyhomepageInitial extends MyhomepageState {}

class CheckInternet extends MyhomepageState {}
