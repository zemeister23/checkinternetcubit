part of 'newpage_cubit.dart';

@immutable
abstract class NewpageState {}

class NewpageInitial extends NewpageState {}
